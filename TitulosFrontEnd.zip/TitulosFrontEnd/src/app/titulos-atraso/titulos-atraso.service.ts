import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Titulo {
  numero: string;
  nomeDevedor: string;
  quantidadeParcelas: number;
  valorOriginal: number;
  dataVencimento: string;
  valorAtualizado: number;
  diasEmAtraso: number;
  multa: number;
  juros: number;
}

@Injectable({ providedIn: 'root' })
export class TitulosAtrasoService {
  private apiUrl = 'https://localhost:44343/v1/titulos/atrasados';

  constructor(private http: HttpClient) {}

  getTitulos(): Observable<Titulo[]> {
    return this.http.get<Titulo[]>(this.apiUrl);
  }
}
