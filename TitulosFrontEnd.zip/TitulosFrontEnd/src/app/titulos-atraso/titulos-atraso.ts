import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { TitulosAtrasoService, Titulo } from './titulos-atraso.service';

@Component({
  selector: 'app-titulos-atraso',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './titulos-atraso.html',
  styleUrl: './titulos-atraso.css',
})

export class TitulosAtrasoComponent implements OnInit {
  titulos: Titulo[] = [];

  constructor(private titulosService: TitulosAtrasoService, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    this.titulosService.getTitulos().subscribe((dados) => {
      console.log('Dados recebidos d da API:', dados);
      this.titulos = dados;
      this.cdr.detectChanges();
      console.log('Qtde', this.titulos.length);
      console.log('numero ', this.titulos[0].numero); 
    });
  }

  formatBRL(valor: number): string {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}
