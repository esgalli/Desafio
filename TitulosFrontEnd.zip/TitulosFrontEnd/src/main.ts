import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { TitulosAtrasoComponent } from './app/titulos-atraso/titulos-atraso';

bootstrapApplication(TitulosAtrasoComponent, appConfig)
  .catch((err) => console.error(err));
